# cpc - big buttons - casino

A Pen created on CodePen.

Original URL: [https://codepen.io/maxew33/pen/gOorpMX](https://codepen.io/maxew33/pen/gOorpMX).

a slot machine with a spin and stop button