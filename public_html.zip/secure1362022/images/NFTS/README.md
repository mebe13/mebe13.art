# Responsive NFT Landing Page

A Pen created on CodePen.

Original URL: [https://codepen.io/erkanerdil016/pen/LYdOpKj](https://codepen.io/erkanerdil016/pen/LYdOpKj).

Inspired by Kukuh Pambudi
"https://www.figma.com/file/nrWq9WXtIcJgnwN4opaIT6/Gaslur-NFT-landingpage-(Community)?node-id=102%3A20"